export function Route ({ path, Component }) {
  return null
}
